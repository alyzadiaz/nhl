import java.sql.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;

import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class Game {
	private String teamName;
	private String opponent;
	private String away;
	private Date day;
	private Time time;
	
	private ImageView teamView;
	private ImageView oppView;
	
	private GridPane gPane;
	private Scene scene;
	
	private ClassLoader cl;

	public Game(String n, String o, String a, Date d, Time t) {
		teamName = n;
		opponent = o;
		away = a;
		day = d;
		time = t;
		
		cl = this.getClass().getClassLoader();
		
		String tn = "logos/"+teamName.toLowerCase()+".png";
		
		teamView = new ImageView(new Image(cl.getResource(tn).toString()));
		teamView.setFitWidth(200);
		teamView.setFitHeight(200);
		
		String on = "logos/"+opponent.toLowerCase()+".png";
		
		oppView = new ImageView(new Image(cl.getResource(on).toString()));
		oppView.setFitWidth(200);
		oppView.setFitHeight(200);
		
		gPane = new GridPane();
		scene = new Scene(gPane, 900, 900);
	}
	
	public void setTeamName(String n) {
		teamName = n;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setOpponent(String o) {
		opponent = o;
	}

	public String getOpponent() {
		return opponent;
	}

	public void setAway(String a) {
		away = a;
	}

	public String getAway() {
		return away;
	}

	public void setDay(Date d) {
		day = d;
	}

	public Date getDay() {
		return day;
	}

	public void setTime(Time t) {
		time = t;
	}

	public Time getTime() {
		return time;
	}

	@SuppressWarnings("static-access")
	public void setup() {
		gPane.setHgap(30);
		gPane.setVgap(50);
		gPane.setAlignment(Pos.CENTER);
		
		Font bankFont = Font.loadFont(cl.getResource("misc/F25_Bank_Printer.otf").toString(), 25);
		Font brushFont = Font.loadFont(cl.getResource("misc/brush.otf").toString(), 30);
		
		Text title = new Text("Next "+opponent+" Game:");
		title.setFont(bankFont);
		
		Text tn = new Text(teamName);
		tn.setFont(brushFont);
		
		Text at = new Text("at");
		at.setFont(bankFont);
		
		Text opp = new Text(opponent);
		opp.setFont(brushFont);
		
		SimpleDateFormat form = new SimpleDateFormat("MM/dd/yyyy");
		Text d = new Text(form.format(day));
		d.setFont(bankFont);

		gPane.add(title, 1, 0);
		gPane.add(at, 1, 2);
		gPane.add(d, 1, 4);
		
		if(away.equals("T")) {
			gPane.add(oppView, 0, 2);
			gPane.add(opp, 0, 3);
			
			gPane.add(teamView, 2, 2);
			gPane.add(tn, 2, 3);
		}else {
			gPane.add(teamView, 0, 2);
			gPane.add(tn, 0, 3);
			
			gPane.add(oppView, 2, 2);
			gPane.add(opp, 2, 3);
		}
		
		for(Node n: gPane.getChildren()) {
			gPane.setHalignment(n, HPos.CENTER);
			gPane.setValignment(n, VPos.CENTER);
		}
	}

	public Scene getScene() {
		return scene;
	}

	public GridPane getGrid() {
		return gPane;
	}
}
