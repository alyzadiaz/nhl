import java.net.URL;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class Player {
	private String teamName;
	private String name;
	private int number;
	private String flag;
	private String position;
	private String height;
	private int weight;
	private int experience;
	private Date dob;
	private int age;
	
	private Image photo;
	private ImageView view;
	private ImageView copy;
	
	private Image country;
	private ImageView viewCountry;
	
	private Button button;
	private Button back;
	
	private VBox vbox;
	private Scene scene;
	
	private BackgroundImage background;
	
	private ClassLoader cl;

	public Player(String a, String b, int c, String d, String f, String g, int h, int i, Date j, int k) {
		teamName = a;
		name = b;
		number = c;
		flag = d;
		position = f;
		height = g;
		weight = h;
		experience = i;
		dob = j;
		age = k;
		
		button = new Button();
		back = new Button("Back");
		
		vbox = new VBox(10);
		vbox.setAlignment(Pos.CENTER);
		scene = new Scene(vbox, 900, 900);
		
		setCountry(flag);
		viewCountry = new ImageView(country);
		
		cl = this.getClass().getClassLoader();
	}

	public void setTeam(String a) {
		teamName = a;
	}

	public String getTeam() {
		return teamName;
	}

	public void setName(String b) {
		name = b;
	}

	public String getName() {
		return name;
	}

	public void setNumber(int c) {
		number = c;
	}

	public int getNumber() {
		return number;
	}

	public void setFlag(String d) {
		flag = d;
	}

	public String getFlag() {
		return flag;
	}

	public void setPos(String f) {
		position = f;
	}

	public String getPos() {
		return position;
	}

	public void setHeight(String g) {
		height = g;
	}

	public String getHeight() {
		return height;
	}

	public void setWeight(int h) {
		weight = h;
	}

	public int getWeight() {
		return weight;
	}

	public void setExp(int i) {
		experience = i;
	}

	public int getExp() {
		return experience;
	}

	public void setDOB(Date j) {
		dob = j;
	}

	public Date getDOB() {
		return dob;
	}

	public void setAge(int k) {
		age = k;
	}

	public int getAge() {
		return age;
	}

	public void print() {
		System.out.printf("%s, %s #%d, %s, %s, height: %s, %d lbs, %d years of exp., ", 
				teamName, name, number, flag, position, height, weight, experience);
		System.out.printf("%1$tA, %1$tB %1$tY,", dob);
		System.out.printf(" %d years old\n", age);
	}

	public void createPhoto(URL url) {
		photo = new Image(url.toString());
		
		view = new ImageView(photo);
		view.setFitWidth(100);
		view.setFitHeight(100);
		
		//a copy of the player's headshot
		copy = new ImageView(photo);
		copy.setFitWidth(250);
		copy.setFitHeight(250);
	}

	public ImageView getPhoto() {
		return view;
	}

	private void setCountry(String f) {
		cl = this.getClass().getClassLoader();
		
		switch(f) {
		case "CAN":
			country = new Image(cl.getResource("flags/can.png").toString());
			break;
		case "CZE":
			country = new Image(cl.getResource("flags/cze.png").toString());
			break;
		case "FIN":
			country = new Image(cl.getResource("flags/fin.png").toString());
			break;
		case "SVK":
			country = new Image(cl.getResource("flags/svk.png").toString());
			break;
		case "SWE":
			country = new Image(cl.getResource("flags/swe.png").toString());
			break;
		case "USA":
			country = new Image(cl.getResource("flags/usa.png").toString());
		}
	}

	public ImageView getCountryFlag() {
		return viewCountry;
	}

	public void setButton(Button b) {
		button = b;
	}

	public Button getButton() {
		return button;
	}

	public Button getBack() {
		return back;
	}

	public VBox getBox() {
		return vbox;
	}

	public BackgroundImage getBackground() {
		return background;
	}

	private void createBackG() {
		String team = "";
		switch(teamName) {
		case "Bruins":
			team = "bruins background.png";
			break;
		case "Blackhawks":
			team = "hawks background.png";
			break;
		}
		
		background = new BackgroundImage(new Image(cl.getResource("misc/"+team).toString(), 900, 900, false, true),
				BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
				BackgroundSize.DEFAULT);
		
		vbox.setBackground(new Background(background));
	}

	public void setup() {
		Font bankFont = Font.loadFont(cl.getResource("misc/F25_Bank_Printer.otf").toString(), 15);
		Font brushFont = Font.loadFont(cl.getResource("misc/brush.otf").toString(), 50);
		
		Text tn = new Text(teamName);
		tn.setFont(bankFont);
		Text n = new Text(name);
		n.setFont(brushFont);
		Text j = new Text("#"+Integer.toString(number));
		j.setFont(bankFont);
		Text f = new Text("Country of Origin: "+flag);
		f.setFont(bankFont);
		Text p = new Text("Position: "+position);
		p.setFont(bankFont);
		Text h = new Text("Height: "+height);
		h.setFont(bankFont);
		Text e = new Text("Years of experience: "+Integer.toString(experience));
		e.setFont(bankFont);
		
		SimpleDateFormat form = new SimpleDateFormat("MM/dd/yyyy");
		Text b = new Text("Birthday: "+form.format(dob));
		b.setFont(bankFont);
		
		Text a = new Text("Age: "+Integer.toString(age));
		a.setFont(bankFont);
		
		createBackG();
		
		vbox.getChildren().addAll(viewCountry, copy, tn, n, j, f, p, h, e, b, a, back);
	}

	public Scene getScene() {
		return scene;
	}
}
