package classes;
import java.util.ArrayList;

public class Team {
	private String teamName;
	private ArrayList<Player> roster;
	
	public Team(String n) {
		teamName = n;
		roster = new ArrayList<>();
	}
	
	public String getTeamName() {
		return teamName;
	}
	
	public ArrayList<Player> getRoster(){
		return roster;
	}
	
	public void addPlayer(Player p) {
		roster.add(p);
	}
	
	public void removePlayer(Player p) {
		int index = playerIndex(p);
		roster.remove(index);
	}

	public Player findPlayer(String name) {
		for(int i=0;i<roster.size();i++) {
			if(roster.get(i).getName().equals(name)) {
				return roster.get(i);
			}
		}
		
		return null;
	}

	public int playerIndex(Player p) {
		String name = p.getName();
		for(int i=0;i<roster.size();i++) {
			if(roster.get(i).getName().equals(name)) {
				return i;
			}
		}
		
		return -1;
	}

	public void printRoster() {
		for(int i=0;i<roster.size();i++) {
			roster.get(i).print();
		}
	}
}
